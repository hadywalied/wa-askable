import path from 'node:path';
import { fileURLToPath } from 'node:url';
import Fastify from 'fastify';
import fastifyStatic from '@fastify/static';
import Anthropic from '@anthropic-ai/sdk';
import type { Config } from '../config.js';
import { openWorkspace, auditWorkspace, type Workspace } from '../core/workspace.js';
import { openDatabase, stats, type DB } from '../core/db.js';
import { WhatsAppArchive } from '../core/whatsapp.js';
import { Enricher, ask } from '../core/enrich.js';
import { listChats, searchMessages } from '../core/search.js';
import { SESSION_TOKEN, assertLoopback, registerSecurity } from './security.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));

interface Runtime {
  ws: Workspace;
  db: DB;
  wa: WhatsAppArchive;
  enricher: Enricher;
  client: Anthropic | null;
}

export async function startServer(cfg: Config): Promise<string> {
  assertLoopback(cfg.host);

  let rt: Runtime | null = null;

  const boot = async (root: string): Promise<Runtime> => {
    const ws = await openWorkspace(root);
    const db = openDatabase(ws.dbPath);
    const wa = new WhatsAppArchive(db, ws.authDir, ws.mediaDir);
    const enricher = new Enricher(db, cfg.anthropicApiKey, cfg.model);
    const client = cfg.anthropicApiKey ? new Anthropic({ apiKey: cfg.anthropicApiKey }) : null;
    return { ws, db, wa, enricher, client };
  };

  const app = Fastify({ logger: false, bodyLimit: 2_000_000 });
  registerSecurity(app, cfg.port);

  await app.register(fastifyStatic, { root: path.join(HERE, '..', 'ui'), index: 'index.html' });

  const need = (): Runtime => {
    if (!rt) throw new Error('no_workspace_open');
    return rt;
  };

  // --- workspace -----------------------------------------------------------

  app.get('/api/session', async () => ({
    token: SESSION_TOKEN,
    localOnly: cfg.localOnly,
    model: cfg.model,
    workspace: rt?.ws.root ?? null,
    defaultWorkspace: cfg.workspaceRoot,
  }));

  app.post<{ Body: { path: string } }>('/api/workspace/open', async (req) => {
    rt = await boot(req.body.path || cfg.workspaceRoot);
    return {
      workspace: rt.ws.root,
      warnings: await auditWorkspace(rt.ws),
      stats: stats(rt.db),
      enrichmentEnabled: rt.enricher.enabled,
    };
  });

  app.get('/api/status', async () => {
    if (!rt) return { workspace: null, connection: { state: 'idle' }, stats: null };
    return {
      workspace: rt.ws.root,
      connection: rt.wa.getStatus(),
      stats: stats(rt.db),
      enrichmentEnabled: rt.enricher.enabled,
      pending: rt.enricher.pendingCount(),
    };
  });

  // --- whatsapp ------------------------------------------------------------

  app.post('/api/whatsapp/connect', async () => {
    await need().wa.connect();
    return need().wa.getStatus();
  });

  app.post('/api/whatsapp/disconnect', async () => {
    await need().wa.disconnect();
    return need().wa.getStatus();
  });

  // --- the refresh button --------------------------------------------------

  /**
   * Note what this does NOT do: it does not fetch messages. The socket already
   * pushed those the moment they arrived. This drains the enrichment backlog
   * those messages created — transliterating Franco, writing English glosses,
   * and (later) transcribing audio.
   */
  app.post('/api/refresh', async () => {
    const { enricher, db } = need();
    const result = await enricher.run(25);
    return { ...result, stats: stats(db) };
  });

  // --- reading -------------------------------------------------------------

  app.get('/api/chats', async () => ({ chats: listChats(need().db) }));

  app.post<{ Body: Record<string, unknown> }>('/api/search', async (req) => ({
    hits: searchMessages(need().db, req.body as never),
  }));

  app.post<{ Body: { question: string } }>('/api/ask', async (req, reply) => {
    const { db, client } = need();
    if (!client) {
      return reply.code(400).send({
        error: 'local_only_mode',
        message:
          'Answering questions needs a model. Set ANTHROPIC_API_KEY in .env and restart, or keep using search, which runs entirely on this machine.',
      });
    }
    return ask(db, client, cfg.model, req.body.question);
  });

  await app.listen({ host: cfg.host, port: cfg.port });
  return `http://${cfg.host}:${cfg.port}/#${SESSION_TOKEN}`;
}
