import { EventEmitter } from 'node:events';
import { createHash } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import makeWASocket, {
  DisconnectReason,
  downloadMediaMessage,
  isJidGroup,
  jidNormalizedUser,
  useMultiFileAuthState,
  Browsers,
  fetchLatestBaileysVersion,
  type WAMessage,
} from '@whiskeysockets/baileys';
import pino from 'pino';
import type { DB, MessageKind } from './db.js';
import { insertMessage, rememberMedia, upsertChat } from './db.js';
import { foldForSearch, stemsForSearch } from './normalize.js';

/**
 * The archive's connection to WhatsApp.
 *
 * Two things worth understanding before you change anything here:
 *
 * 1. This is a *linked device*, not a scrape. WhatsApp allows four; we occupy
 *    one. Your phone keeps working untouched. Nothing is sent, ever — the
 *    socket is configured to listen and mark nothing as read, so the people
 *    messaging you see no change in behaviour.
 *
 * 2. Messages arrive by push, not by poll. There is no "fetch new messages"
 *    call to make. While connected, messages.upsert fires in real time; on
 *    first link, WhatsApp pushes a history blob through messaging-history.set.
 *    That blob is partial and unreliable and is the only past you will ever
 *    get. Everything else is the future.
 */

export type ConnState = 'idle' | 'connecting' | 'qr' | 'open' | 'closed' | 'logged_out';

export interface WhatsAppStatus {
  state: ConnState;
  qrDataUrl?: string;
  selfJid?: string;
  lastError?: string;
  capturedThisSession: number;
}

type Sock = ReturnType<typeof makeWASocket>;

function messageKind(msg: WAMessage): MessageKind {
  const m = msg.message;
  if (!m) return 'other';
  if (m.conversation || m.extendedTextMessage) {
    const text = m.conversation ?? m.extendedTextMessage?.text ?? '';
    return /https?:\/\//i.test(text) ? 'link' : 'text';
  }
  if (m.imageMessage) return 'image';
  if (m.videoMessage) return 'video';
  if (m.audioMessage) return 'audio';
  if (m.documentMessage) return 'document';
  if (m.stickerMessage) return 'sticker';
  if (m.locationMessage) return 'location';
  if (m.contactMessage) return 'contact';
  return 'other';
}

/** Whatever readable text the message carries. Media captions count. */
function messageText(msg: WAMessage): string {
  const m = msg.message;
  if (!m) return '';
  return (
    m.conversation ??
    m.extendedTextMessage?.text ??
    m.imageMessage?.caption ??
    m.videoMessage?.caption ??
    m.documentMessage?.caption ??
    m.documentMessage?.fileName ??
    m.locationMessage?.address ??
    m.contactMessage?.displayName ??
    ''
  );
}

function timestampMs(msg: WAMessage): number {
  const t = msg.messageTimestamp;
  if (typeof t === 'number') return t * 1000;
  if (typeof t === 'bigint') return Number(t) * 1000;
  return Date.now();
}

export class WhatsAppArchive extends EventEmitter {
  private sock: Sock | null = null;
  private status: WhatsAppStatus = { state: 'idle', capturedThisSession: 0 };
  private stopping = false;

  constructor(
    private readonly db: DB,
    private readonly authDir: string,
    private readonly mediaDir: string,
  ) {
    super();
  }

  getStatus(): WhatsAppStatus {
    return { ...this.status };
  }

  private setStatus(patch: Partial<WhatsAppStatus>): void {
    this.status = { ...this.status, ...patch };
    this.emit('status', this.getStatus());
  }

  async connect(): Promise<void> {
    this.stopping = false;
    this.setStatus({ state: 'connecting', lastError: undefined });

    const { state, saveCreds } = await useMultiFileAuthState(this.authDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      version,
      auth: state,
      // Identifying as a desktop client makes WhatsApp send a larger initial
      // history blob than the default browser identity does.
      browser: Browsers.macOS('Desktop'),
      syncFullHistory: true,
      // Two settings that keep this invisible to the people messaging you:
      // no online presence, and no blue ticks from the archive.
      markOnlineOnConnect: false,
      logger: pino({ level: 'silent' }) as never,
    });
    this.sock = sock;

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (qr) {
        // printQRInTerminal was removed from Baileys; the QR string is ours to
        // render. The UI shows it as an image so there is no terminal step.
        const { toDataURL } = await import('qrcode');
        this.setStatus({ state: 'qr', qrDataUrl: await toDataURL(qr, { margin: 1, width: 320 }) });
      }

      if (connection === 'open') {
        this.setStatus({
          state: 'open',
          qrDataUrl: undefined,
          selfJid: sock.user?.id ? jidNormalizedUser(sock.user.id) : undefined,
        });
      }

      if (connection === 'close') {
        const code = (lastDisconnect?.error as { output?: { statusCode?: number } } | undefined)
          ?.output?.statusCode;
        if (code === DisconnectReason.loggedOut) {
          // The link was revoked from the phone. Credentials are dead; the user
          // has to scan again. Reconnecting in a loop here would be pointless.
          this.setStatus({ state: 'logged_out', lastError: 'Device was unlinked from the phone.' });
          return;
        }
        this.setStatus({ state: 'closed', lastError: String(lastDisconnect?.error ?? 'closed') });
        if (!this.stopping) setTimeout(() => void this.connect(), 3_000);
      }
    });

    // Live traffic.
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      if (type !== 'notify' && type !== 'append') return;
      for (const msg of messages) await this.capture(msg);
    });

    // The one-time history blob pushed shortly after linking.
    sock.ev.on('messaging-history.set', async ({ messages, chats }) => {
      for (const c of chats ?? []) {
        upsertChat(this.db, {
          jid: c.id,
          name: c.name ?? null,
          isGroup: isJidGroup(c.id) ?? false,
          ts: Number(c.conversationTimestamp ?? 0) * 1000 || Date.now(),
        });
      }
      for (const msg of messages ?? []) await this.capture(msg);
      this.emit('history-synced', { messages: messages?.length ?? 0 });
    });
  }

  async disconnect(): Promise<void> {
    this.stopping = true;
    this.sock?.end(undefined);
    this.sock = null;
    this.setStatus({ state: 'idle', qrDataUrl: undefined });
  }

  /** Persist one message. Media is hashed and stored once per unique file. */
  private async capture(msg: WAMessage): Promise<void> {
    const jid = msg.key.remoteJid;
    if (!jid || jid === 'status@broadcast') return;
    if (!msg.message) return;

    const id = `${jid}:${msg.key.id}`;
    const ts = timestampMs(msg);
    const isGroup = isJidGroup(jid) ?? false;

    upsertChat(this.db, { jid, name: msg.pushName ?? null, isGroup, ts });

    const kind = messageKind(msg);
    let mediaSha: string | null = null;

    if (kind === 'image' || kind === 'video' || kind === 'audio' || kind === 'document') {
      try {
        mediaSha = await this.storeMedia(msg, kind);
      } catch {
        // A failed download must never lose the message row. The text and
        // metadata are still worth having; enrichment can retry the file later.
        mediaSha = null;
      }
    }

    const raw = messageText(msg);
    insertMessage(this.db, {
      id,
      chat_jid: jid,
      sender_jid: msg.key.participant ? jidNormalizedUser(msg.key.participant) : jid,
      sender_name: msg.pushName ?? null,
      ts,
      from_me: msg.key.fromMe ? 1 : 0,
      kind,
      body_raw: raw,
      body_ar: foldForSearch(raw),
      body_stem: stemsForSearch(raw),
      body_en: '',
      media_sha256: mediaSha,
      quoted_id: msg.message.extendedTextMessage?.contextInfo?.stanzaId ?? null,
      // Plain text with no Arabic and no media needs nothing further.
      enrich_state: kind === 'text' && !raw ? 'skipped' : 'pending',
    });

    this.setStatus({ capturedThisSession: this.status.capturedThisSession + 1 });
    this.emit('captured', { id, chatJid: jid, kind });
  }

  /**
   * Download once, keyed by content hash.
   *
   * The same forwarded video reaches you from five groups. Hashing the bytes
   * means it occupies one file and earns one transcription, no matter how many
   * messages point at it.
   */
  private async storeMedia(msg: WAMessage, kind: MessageKind): Promise<string> {
    const buffer = (await downloadMediaMessage(msg, 'buffer', {})) as Buffer;
    const sha = createHash('sha256').update(buffer).digest('hex');

    const { isNew } = rememberMedia(this.db, {
      sha256: sha,
      kind,
      byteSize: buffer.byteLength,
      relPath: path.join(kind, `${sha}.bin`),
    });

    if (isNew) {
      const dir = path.join(this.mediaDir, kind);
      await mkdir(dir, { recursive: true });
      await writeFile(path.join(dir, `${sha}.bin`), buffer, { mode: 0o600 });
    }
    return sha;
  }
}
