import { randomBytes } from 'node:crypto';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';

/**
 * "It runs locally" is not a security model.
 *
 * Three specific things are wrong with assuming localhost is safe, and this
 * module addresses the first two. The third is your problem, not the code's.
 *
 * 1. ANY website you visit can make requests to http://127.0.0.1:<port>.
 *    A page open in another tab can fire fetch() at your archive and, without
 *    a check, read every message you own. This is a real, routinely-exploited
 *    class of bug in local dev tools. We block it two ways: a shared secret
 *    the browser only gets by loading our own page, and an Origin/Sec-Fetch
 *    check that rejects anything initiated by another site.
 *
 * 2. Binding to 0.0.0.0 puts your entire message history on the coffee-shop
 *    wifi. Node's default for many frameworks is all interfaces. We bind to
 *    the loopback address explicitly and refuse to start otherwise.
 *
 * 3. The WhatsApp credentials in your workspace are a full account takeover
 *    for anyone who reads them. No amount of server code fixes that — it needs
 *    filesystem permissions, an encrypted disk, and a .gitignore you trust.
 *    See assertWorkspacePermissions() in workspace.ts.
 */

export const LOOPBACK = '127.0.0.1';

/** Regenerated every process start, so a leaked token dies on restart. */
export const SESSION_TOKEN = randomBytes(32).toString('base64url');

/** Paths served without a token — only the shell that bootstraps the token. */
const PUBLIC_PATHS = new Set(['/', '/index.html', '/app.css', '/app.js', '/favicon.ico']);

function isSameOriginRequest(req: FastifyRequest, port: number): boolean {
  // Modern browsers send this on every request and it cannot be forged by
  // page JavaScript. 'same-origin' and 'none' (address-bar navigation) are ok.
  const fetchSite = req.headers['sec-fetch-site'];
  if (typeof fetchSite === 'string') {
    return fetchSite === 'same-origin' || fetchSite === 'none';
  }
  // Fallback for older clients: an Origin header, if present, must be us.
  const origin = req.headers.origin;
  if (typeof origin === 'string') {
    return origin === `http://${LOOPBACK}:${port}` || origin === `http://localhost:${port}`;
  }
  // No Origin and no Sec-Fetch-Site: a non-browser client (curl, a test).
  // Those still need the token, which is checked separately.
  return true;
}

function presentedToken(req: FastifyRequest): string | undefined {
  const header = req.headers['x-session-token'];
  if (typeof header === 'string') return header;
  const auth = req.headers.authorization;
  if (typeof auth === 'string' && auth.startsWith('Bearer ')) return auth.slice(7);
  return undefined;
}

/** Constant-time-ish compare. Tokens are fixed length, so length differs => reject. */
function tokenMatches(candidate: string | undefined): boolean {
  if (!candidate || candidate.length !== SESSION_TOKEN.length) return false;
  let diff = 0;
  for (let i = 0; i < SESSION_TOKEN.length; i++) {
    diff |= candidate.charCodeAt(i) ^ SESSION_TOKEN.charCodeAt(i);
  }
  return diff === 0;
}

export function registerSecurity(app: FastifyInstance, port: number): void {
  app.addHook('onRequest', async (req: FastifyRequest, reply: FastifyReply) => {
    // Never send permissive CORS. The UI is same-origin; nothing else is allowed.
    reply.header('Access-Control-Allow-Origin', 'null');
    reply.header('X-Content-Type-Options', 'nosniff');
    reply.header('Referrer-Policy', 'no-referrer');
    // No remote anything: the UI is fully local, so a strict CSP costs nothing
    // and stops an injected string from phoning home with your messages.
    reply.header(
      'Content-Security-Policy',
      "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'",
    );

    if (!isSameOriginRequest(req, port)) {
      return reply.code(403).send({ error: 'cross_site_request_blocked' });
    }

    const path = req.url.split('?')[0] ?? '/';
    if (PUBLIC_PATHS.has(path)) return;

    if (!tokenMatches(presentedToken(req))) {
      return reply.code(401).send({ error: 'bad_or_missing_session_token' });
    }
  });
}

/**
 * Refuse to start on anything but loopback. Called before listen() so a typo in
 * an env var can't silently publish the archive to the local network.
 */
export function assertLoopback(host: string): void {
  if (host !== LOOPBACK && host !== 'localhost' && host !== '::1') {
    throw new Error(
      `Refusing to bind to "${host}". This server holds other people's private messages ` +
        `and must only listen on ${LOOPBACK}. If you genuinely need remote access, put it ` +
        `behind an SSH tunnel rather than changing this.`,
    );
  }
}
